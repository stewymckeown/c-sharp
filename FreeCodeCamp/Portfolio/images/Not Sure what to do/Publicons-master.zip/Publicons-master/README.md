Publicons
=========

http://joshuasortino.com/projects/publicons

A collection of finely tuned publishing and platform icons by @joshuasortino

I was sick and tired of recreating icons for publishing platforms that typically are not included in icon sets. If you see a platform that is missing, please let me know on Twitter. You're also welcome to add to this project!

These are provided free of charge under the MIT License. I do not claim to have created the original logos, only these icons which represent the original logos. If you decide to incorporate them into your project, I'd love to know!
