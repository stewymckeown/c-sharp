Flat Social Media Icons

Flat Social Media Icons is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/). 

You are allowed to use these elements anywhere you want, however we�ll highly appreciate if you will link to our website when you share them - http://designmodo.com

Thanks for supporting our website and enjoy!

Links:
http://designmodo.com/flat-social-icons

ATENTION! Buy Now Premium version of Flat UI! - http://designmodo.com/flat/

